<<<<<<< HEAD
#Projeto: OER Labs
##URL: https://oerlabs.com.br/
##Autor: Henrique Olivetti
##Email: henrique@oerlabs.com.br
##Celular: 21 99523-8400

=======
https://github.com/oerlabshenrique/oerlabs
Git init
Git status
Git add .
Git commit -m "Projeto OER Labs"
Git push
Git pull
=======
=======
#Projeto: OER Labs
##URL: https://oerlabs.com.br/
##Autor: Henrique Olivetti
##Email: henrique@oerlabs.com.br
##Celular: 21 99523-8400

=======
https://github.com/oerlabshenrique/oerlabs
Git init
Git status
Git add .
Git commit -m "Projeto OER Labs"
Git push
Git pull
=======
>>>>>>> ddc1b5f28af65ddd5466b20782691bfa1d8dc9dd
