
## OER Labs

[:octocat: Git OER Labs](https://github.com/oerlabshenrique)
      <h6>Desenvolvimento & Analise de Projetos</h6>


Autor: Henrique Olivetti <br>
URL: https://oerlabs.com.br/ <br>
Email: henrique@oerlabs.com.br<br> 
Celular: 21 99523-8400</h6><br>

<h6>
<div>
:octocat: https://github.com/oerlabshenrique/oerlabs<br>
<br>
  :heavy_check_mark: Git init<br>
  :heavy_check_mark:Git status<br>
  :heavy_check_mark:Git add .<br>
  :heavy_check_mark:Git commit -m "Projeto OER Labs"<br>
  :heavy_check_mark:Git push<br>
  :heavy_check_mark:Git pull<br>
</div>
</h6>

##
 
<table>

<thead>
<tr>
<th colspan="2">Quick Info</th>
</tr>
</thead>
      
<tbody>
<tr><th scope='row'>Name</th><td>Henrique Olivetti</td></tr>
<tr><th scope='row'>Born</th><td><time datetime="">Rio de Janeiro</time></td></tr>
<tr><th scope='row'>Education</th><td>Analise de Sistemas</td></tr>
<tr><th scope='row'>University</th><td>Estácio de Sá</td></tr>
<tr><th scope='row'>Occupation</th><td>Web Developer</td></tr>
<tr><th scope='row'>Skills</th><td>HTML, CSS, JavaScript, Node.js, SEO</td></tr>
</tbody>
</table>


 ##

<br>

<img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=oerlabshenrique&layout=compact&langs_count=16&theme=dracula"/>
 
<div style="display: inline_block"><br>
  <img align="center" alt="Rafa-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Rafa-Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="Rafa-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" alt="Rafa-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Rafa-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Rafa-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Rafa-Csharp" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg">       
 </div>
  
  ##
 
<div> 
 
 <a href="https://github.com/oerlabshenrique" target="_blank"><img src="https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white" target="_blank"></a>
  <a href="https://www.facebook.com/ricolivetti" target="_blank"><img src="https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white" target="_blank"></a>
  <a href="https://twitter.com/ricoolivetti" target="_blank"><img src="https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white" target="_blank"></a>
  <a href="https://www.instagram.com/henriqueolivettioficial" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
 <a href="https://www.linkedin.com/in/henriqueolivetti" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
 <a href="https://instagram.com/rafaballerini" target="_blank"><img src="https://img.shields.io/badge/Adobe%20Photoshop-31A8FF?style=for-the-badge&logo=Adobe%20Photoshop&logoColor=white" target="_blank"></a>
 <a href="https://instagram.com/rafaballerini" target="_blank"><a href="https://img.shields.io/badge/Adobe%20Photoshop-31A8FF?style=for-the-badge&logo=Adobe%20Photoshop&logoColor=white" target="_blank"></a>
 
</div>

=======

## OER Labs
